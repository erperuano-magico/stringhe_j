/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.stringhe_j;

/**
 *
 * @israel amayo 4id 16-11-2024
 * consegna 
 * scrivi un programma che lasci inserire ad un utente una stringa e cerchi quante volte
 * appare la lettera "a" in essa successivamente stampa la lettera "a" in maiuscolo tante volte quanto è stata trovata.
 */
public class Stringhe_j {

    public static void main(String[] args) {
        //creazione dell'oggetto della classe lettera
        lettera lettera1= new lettera ();
        
        //richiamo della funzione inizializzazione
        lettera1.inizializzazione();
        
    }
}
